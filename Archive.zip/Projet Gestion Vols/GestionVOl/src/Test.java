
public class Test {

	public static void main(String[] args) {
ConnexionDB cnx=new ConnexionDB();

System.out.println(cnx.getConnect());
	}

}
