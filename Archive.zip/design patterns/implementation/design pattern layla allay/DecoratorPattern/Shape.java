package DecoratorPattern;

public interface Shape {
	   void draw();
	}