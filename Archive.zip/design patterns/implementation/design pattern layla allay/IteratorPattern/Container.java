package IteratorPattern;

public interface Container {
	   public Iterator getIterator();
	}