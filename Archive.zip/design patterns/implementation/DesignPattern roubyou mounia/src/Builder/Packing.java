package Builder;

public interface Packing {
	   public String pack();
	}
