package Facad;

public interface Shape {
	   void draw();
	}
