package FlyweightPattern;

public interface Shape {

	void draw();
}
