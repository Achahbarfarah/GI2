package FlyweightPattern;

public class m {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Circle c =new Circle("Green");
		c.setX(5);
		c.setY(3);
		c.setRadius(20);
		c.draw();
	}

	
}
