package Proxy;

public interface Image {
	void display();
}
